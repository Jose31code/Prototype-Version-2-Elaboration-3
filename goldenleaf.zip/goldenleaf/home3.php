<!doctype html>
<html lang="zxx">
  <head>
    <title>Golden Leaf</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/logo.png">    
    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700;800;900&display=swap" rel="stylesheet">  
    <!-- Styles -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/animate.css">     
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/lightbox.css">      
    <link rel="stylesheet" href="css/fontawesome.css">     
    <!-- Custom styles -->
    <link href="style.css" type="text/css" rel="stylesheet">
  </head>
  <body>

  <div class="full-screen2">
    <div class="toprow">
      <div class="row">
        <div class="col-lg-4">
          <!-- Card and shop icon --> 
          <div class="smallscreen">
            <div class="shop-icon navbar">
              <div class="dropdown">
		            <a href="#" data-toggle="dropdown">
                  <i class="fas fa-shopping-cart"></i>
                  <span class="totalnumberitems">3</span>
                  <span class="shop-icon-total">$29</span>
                </a>               
                <div class="dropdown-menu">
                  <div class="card">
                    <div class="card-body">
                      <div class="row justify-content-center pb-1">
                        <div class="col-4">
                        </div>
                        <div class="col-8">
                          <h4 class="mb-0">Chicken Salad</h4> 
                          <span>$12</span>
                        </div>
                      </div>
                      <div class="row justify-content-center pb-1">
                        <div class="col-4">
                          
                        </div>
                        <div class="col-8">
                          <h4 class="mb-0">Vegan Burger</h4>
                          <span>$10</span>                     
                        </div>
                      </div>
                      <div class="row justify-content-center pb-2">
                        <div class="col-4">
                        
                        </div>
                        <div class="col-8">
                          <h4 class="mb-0">Chikpea Nuggets</h4>
                          <span>$7</span>                     
                          </div>
                      </div>
                      <div class="line"></div>
                      <div class="col-12 pb-1half pt-1">
                        <div class="row no-gutters">
                          <div class="col-6">
                          <h4>TOTAL</h4> 
                          </div>
                          <div class="col-6 text-right">
                            <h4><b>$29</b></h4> 
                          </div>
                        </div>  
                      </div>
                      <div class="line mb-1"></div>
                      <div class="col-12 text-center">
                        <a href="#" class="custom-button2">Checkout</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--logo-->
        <div class="home3 col-lg-4 text-center">
          <a class="navbar-brand" href="home3.php"><img src="images/goldenleaf.PNG"></a>
        </div>
        <!--menu-->
        <div class="col-lg-4">
          <a class="nav-button ml-auto mr-4"><span id="nav-icon3"><span></span><span></span><span></span><span></span></span></a>
            <div class="fixed-top main-menu">
              <div class="flex-center p-5">
                <div class="flex-column">
                  <a data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                  Home <i class="fa fa-chevron-down"></i>
                  </a>
                  <div class="collapse" id="collapseExample">
                    <a href="home3.php">Return to Home Page</a>
                  </div>
                  <a data-toggle="collapse" href="#collapseExample2" role="button" aria-expanded="false" aria-controls="collapseExample2">
                  Order <i class="fa fa-chevron-down"></i>
                  </a>
                  <div class="collapse" id="collapseExample2">
                    <a href="menus.html">View Menu</a>                    
                    <a href="cart.html">Cart</a>
                  </div>
                  <a data-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample1">
                  Account <i class="fa fa-chevron-down"></i>
                  </a>
                  <div class="collapse" id="collapseExample1">
                    <li><a class="dropdown-item" href="login.php">Log In</a></li>
                    <li><a class="dropdown-item" href="register.php">Register</a></li>	
                  </div>
                </div>
              </div>
            </div> 
          </div> 
        </div> 
      </div>  
      <div class="row h-100 align-items-center">
      <div class="col-lg-4 h-100 full-row1">
        <div class="row pl-5 h-100 full-row1-inner align-items-center">
          <div data-josh-anim-name="heartBeat" class="josh-js textbox col-md-6 col-sm-3 col-12">
            <a href="menus.html"><h2>HOUSE</h2><h3>BURGERS</h3></a>
            <p>Vegan, Gluten-Free, and Dairy-Free 0ptions available</p>
            <span>from</span>
            <h4>$9</h4>
          </div>
        </div>
      </div>
      <div class="col-lg-4 h-100 full-row2">
        <div class="row pl-5 h-100 full-row2-inner align-items-center">   
          <div data-josh-anim-name="heartBeat" class="josh-js textbox col-md-6 col-sm-3 col-12">
            <a href="menus.html"><h2>DELICIOUS</h2><h3>ENTRES</h3></a>
            <p>Try our new ENTRES!! Vegan, Dairy-Free, and Gluten-Free options available. </p>
            <span>from</span>
            <h4>$12</h4>
          </div>
        </div>
      </div>
      <div class="col-lg-4 h-100 full-row3">
        <div class="row pl-5 h-100 full-row3-inner align-items-center">
          <div data-josh-anim-name="heartBeat" class="josh-js textbox col-md-6 col-sm-3 col-12">
            <a href="menus.html"><h2>HEALTHY</h2><h3>SIDES</h3></a>
            <p>Hold the fries, were changing it up a bit!</p>
            <span>from</span>
            <h4>$6</h4>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="js/jquery.js"></script>
  <script src="js/waypoints.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/isotope.js"></script> 
  <script src="js/imagesloaded.js"></script> 
  <script src="js/lightbox.js"></script> 
  <script src="js/simple-load-more.js"></script>
  <script src="js/josh.min.js"></script>
  <script src="js/flexslider.js"></script>  
  <script src="js/script.js"></script>
  </body>
</html>