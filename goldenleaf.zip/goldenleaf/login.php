<?php include('server.php')?> 
<!doctype html>
<html lang="zxx">
  <head>
    <title>Green Leaf</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/logo.png">    
    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700;800;900&display=swap" rel="stylesheet">  
    <!-- Styles -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/animate.css">     
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/lightbox.css">      
    <link rel="stylesheet" href="css/fontawesome.css">     
    <!-- Custom styles -->
    <link href="style.css" type="text/css" rel="stylesheet">
  </head>
  <body>
  <div class="white-nav">  
    <div class="container pl-0 pr-0">
      <div class="row overflows smallscreen-wrapper">
        <div class="col-lg-2 col-12 text-center">
          <a class="navbar-brand" href="home3.php"><img src="images/logo.png"></a>
        </div>   
        <div class="col-lg-10 col-12 navbar-wrapper">
          <nav class="navbar navbar-expand-lg">
            <button class="navbar-toggler first-button" type="button" data-toggle="collapse" data-target="#main_nav"
            aria-controls="main_nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="animated-icon1"><span></span><span></span><span></span></span>
            </button> 
            <div class="collapse navbar-collapse" id="main_nav">
              <ul class="navbar-nav">
	              <li class="nav-item dropdown">
		              <a class="nav-link" href="#" data-toggle="dropdown">Home <i class="dropdown-icon fa fa-chevron-down"></i></a>
	                <ul class="dropdown-menu fade-down">
		        
                    <li><a class="dropdown-item" href="home3.php">Return to Home Page</a></li>
	                </ul>
	              </li>
                <li class="nav-item dropdown">
                	<a class="nav-link" href="#" data-toggle="dropdown"> Order <i class="dropdown-icon fa fa-chevron-down"></i></a>
	                <ul class="dropdown-menu fade-down">
		                <li><a class="dropdown-item" href="menus.html">Menu</a></li>                
                    <li><a class="dropdown-item" href="cart.html">View Cart</a></li>
	                </ul>
                </li>
	              <li class="nav-item">
	              </li>
                <li class="nav-item dropdown">
		              <a class="nav-link" href="#" data-toggle="dropdown">Account<i class="dropdown-icon fa fa-chevron-down"></i></a>
	                <ul class="dropdown-menu fade-down">
		                <li><a class="dropdown-item" href="login.php">Log In</a></li>	              
                    <li><a class="dropdown-item" href="register.php">Create Account</a></li>	
                  </ul>
	              </li>
                <li class="nav-item">
	              </li>
              </ul>
            </div>
          </nav>     
      <div class="col-md-6">
        <h2>Log In</h2> 
        <form action="login.php" method="POST">
        
        <div>
            <label for="username">Username : </label>
            <input type="text" name="username" required>
        </div>

        <div>
            <label for="password">Password : </label>
            <input type="password" name="password_1" required>
        </div>
 
        <button type="submit" name="login_user"> Login </button>

        <p>Not a user?<a href="register.php"><b> Register Here</b></a></p>
        <div class="row">
          <div class="col-12 mt-1 mb-3 text-right">
            <a href="#" class="custom-button2">Log In</a>  
          </div>
        </div>
        <div class="row">
          <div class="col-sm-5">
          </div>
        </div> 
      </div>  
    </div>
  </div>
  </main>
  <!-- Footer -->
  <footer class="footer">
		<div class="container footer-inner">
		  <div class="fade-in-up row pl-5 pr-3 no-gutters">
        <div class="col-lg-6 col-md-12">
          <div class="row no-gutters">
            <div class="col-lg-5 col-md-6 mb-1">
		          <a href="#"><img class="footer-logo" src="images/logo_footer.png"></a>
	          </div>
		        <div class="col-lg-7 col-md-6 mb-1">
		          <h3 class="footertitle">Quick links</h3>
              <ul class="footerul">
                <li><a href="#">Menus</a> </li>
				        <li><a href="#">Order</a> </li>
				        <li><a href="#">View Cart</a> </li>
					      
              </ul>  
	          </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-12">
          <div class="row no-gutters">
	          <div class="col-lg-7 col-md-6 mb-1">
	            <h3 class="footertitle">Contact</h3>
              <ul class="footerul">
                <li class="footerul1">Hours </li>
				        <li class="footerul2">Sunday - Saturday<br> 8:00am - 8:00pm</li>
				        <li class="footerul1">Address </li>
					      <li class="footerul2">700 E 7th St. St Paul, MN 55106</li>
              </ul>  
		        </div>
            <div class="col-lg-5 col-md-6 mb1">
	            <h3 class="footertitle footertitle2">Call us now</h3>
              <h5 class="footercta">+ 612 000 0911</h5>
		          <h5 class="footercta">+ 763 000 0911</h5>
		        </div>
          </div>
        </div>
		  </div>
      <div class="col-12 text-center pt-2">
	  </div>
	  </div>
    <div id="toTopBtn" class="fa fa-chevron-up button-top"></div>  
  </footer>
  <script src="js/jquery.js"></script>
  <script src="js/waypoints.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/isotope.js"></script> 
  <script src="js/imagesloaded.js"></script> 
  <script src="js/lightbox.js"></script> 
  <script src="js/simple-load-more.js"></script>
  <script src="js/josh.min.js"></script>
  <script src="js/flexslider.js"></script>  
  <script src="js/script.js"></script>
  </body>
</html>